-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : Mon, 20 Apr 2026 12:09:30 GMT
-- Request id : cfwk-fed377c2-69e6177a49edd

library ieee;
use ieee.std_logic_1164.all;

entity tb_clk_en is
end tb_clk_en;

architecture tb of tb_clk_en is

    component clk_en
        port (clk    : in std_logic;
              rst    : in std_logic;
              ce_1ms : out std_logic);
    end component;

    signal clk    : std_logic;
    signal rst    : std_logic;
    signal ce_1ms : std_logic;

    constant TbPeriod : time := 10 ns; -- ***EDIT*** Put right period here
    signal TbClock : std_logic := '0';
    signal TbSimEnded : std_logic := '0';

begin

    dut : clk_en
    port map (clk    => clk,
              rst    => rst,
              ce_1ms => ce_1ms);

    -- Clock generation
    TbClock <= not TbClock after TbPeriod/2 when TbSimEnded /= '1' else '0';

    -- ***EDIT*** Check that clk is really your main clock signal
    clk <= TbClock;

    p_stimuli : process
begin
    -- 1. Stav: Reset (Inicializace systému)
    rst <= '1';
    wait for 50 ns;
    rst <= '0';
    wait for TbPeriod;

    -- 2. Stav: Sledování čítání
    -- V simulaci nechceme čekat 1 ms (to je 100 000 taktů), 
    -- trvalo by to dlouho. Pro test se dívej, zda se čítač s_cnt zvedá.
    -- Pokud chceš vidět puls ce_1ms, musíš počkat:
    wait for 1 ms; 
    
    -- V tento moment by ce_1ms měl být na jeden takt v '1'
    assert ce_1ms = '1' report "CHYBA: Puls ce_1ms se neobjevil po 1 ms!" severity error;
    
    wait for TbPeriod;
    wait for 100 * TbPeriod; 
    rst <= '1';               
    wait for 20 ns;
    assert ce_1ms = '0' report "CHYBA: Reset nevynuloval výstup!" severity error;
    rst <= '0';

    wait for 100 ns;
    report "Simulace clock_en uspesne dokoncena!";
    std.env.stop; 
end process;
end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_clk_en of tb_clk_en is
    for tb
    end for;
end cfg_tb_clk_en;