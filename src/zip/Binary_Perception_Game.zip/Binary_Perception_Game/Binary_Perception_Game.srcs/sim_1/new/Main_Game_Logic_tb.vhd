-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : Mon, 20 Apr 2026 12:27:54 GMT
-- Request id : cfwk-fed377c2-69e61bca99f05

library ieee;
use ieee.std_logic_1164.all;

entity tb_Main_Game_logic is
end tb_Main_Game_logic;

architecture tb of tb_Main_Game_logic is

    component Main_Game_logic
        port (clk        : in std_logic;
              rst        : in std_logic;
              ce_1ms     : in std_logic;
              btn_start  : in std_logic;
              match      : in std_logic;
              target_en  : out std_logic;
              show_time  : out std_logic;
              time_bcd_h : out std_logic_vector (3 downto 0);
              time_bcd_t : out std_logic_vector (3 downto 0);
              time_bcd_u : out std_logic_vector (3 downto 0));
    end component;

    signal clk        : std_logic;
    signal rst        : std_logic;
    signal ce_1ms     : std_logic;
    signal btn_start  : std_logic;
    signal match      : std_logic;
    signal target_en  : std_logic;
    signal show_time  : std_logic;
    signal time_bcd_h : std_logic_vector (3 downto 0);
    signal time_bcd_t : std_logic_vector (3 downto 0);
    signal time_bcd_u : std_logic_vector (3 downto 0);

    constant TbPeriod : time := 10 ns; -- ***EDIT*** Put right period here
    signal TbClock : std_logic := '0';
    signal TbSimEnded : std_logic := '0';

begin

    dut : Main_Game_logic
    port map (clk        => clk,
              rst        => rst,
              ce_1ms     => ce_1ms,
              btn_start  => btn_start,
              match      => match,
              target_en  => target_en,
              show_time  => show_time,
              time_bcd_h => time_bcd_h,
              time_bcd_t => time_bcd_t,
              time_bcd_u => time_bcd_u);

    -- Clock generation
    TbClock <= not TbClock after TbPeriod/2 when TbSimEnded /= '1' else '0';

    -- ***EDIT*** Check that clk is really your main clock signal
    clk <= TbClock;

   p_stimuli : process
begin
    -- --- 1. INICIALIZACE A RESET ---
    rst <= '1';
    btn_start <= '0';
    match <= '0';
    wait for 50 ns;
    rst <= '0';
    wait for 20 ns;
    -- Teď by měla být komponenta ve stavu S_IDLE (všechny výstupy 0)

    -- --- 2. START HRY (Přechod do S_GEN a S_RUN) ---
    btn_start <= '1';
    wait for 10 ns; -- Jeden takt 100MHz hodin
    btn_start <= '0';
    wait for 10 ns;
    -- Teď by měl target_en na jeden takt bliknout (S_GEN) a pak přejít do S_RUN
    
    -- --- 3. TEST POČÍTÁNÍ ČASU (S_RUN) ---
    -- Simulujeme příchod 5 desetin sekundy (pro test stačí pár)
    -- Každých 100ms (což je 100x ce_1ms) se má zvednout čas o 1
    for i in 1 to 3 loop
        -- Simulujeme 100 pulzů ce_1ms, aby se pohnuly stopky o jednu desetinu
        for j in 1 to 100 loop
            ce_1ms <= '1';
            wait for 10 ns;
            ce_1ms <= '0';
            wait for 40 ns; -- Mezera mezi pulzy (v reálu je mnohem větší)
        end loop;
        report "Probehla jedna desetina sekundy.";
    end loop;
    -- V tuhle chvíli by na time_bcd_u měla být hodnota "3" (0.3s)

    -- --- 4. TEST VÝHRY (Přechod do S_WIN) ---
    match <= '1';
    wait for 20 ns;
    -- Teď by se měl show_time nastavit na '1' a stopky se zastavit
    match <= '0'; -- Hráč mohl páčkami pohnout dál, ale čas musí držet
    
    -- --- 5. TEST NÁVRATU DO IDLE ---
    wait for 100 ns;
    btn_start <= '1'; -- V S_WIN tlačítko start vrací hru na začátek
    wait for 10 ns;
    btn_start <= '0';
    
    wait for 100 ns;
    report "Testbench game_logic dokoncen!";
    std.env.stop;
end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_Main_Game_logic of tb_Main_Game_logic is
    for tb
    end for;
end cfg_tb_Main_Game_logic;