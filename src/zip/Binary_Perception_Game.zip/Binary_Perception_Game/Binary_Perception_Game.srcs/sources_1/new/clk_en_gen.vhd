----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/15/2026 06:47:44 PM
-- Design Name: 
-- Module Name: clk_en_gen - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity clk_en_gen is
    Port ( clk : in STD_LOGIC;
           rst : in STD_LOGIC;
           ce_1ms : out STD_LOGIC;
           ce_100ms : out STD_LOGIC);
end clk_en_gen;

architecture Behavioral of clk_en_gen is

begin


end Behavioral;
